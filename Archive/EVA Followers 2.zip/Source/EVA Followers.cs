using UnityEngine;
using System.Collections.Generic;
using System;

namespace EVA_CMD {
[KSPAddon(KSPAddon.Startup.MainMenu, true)]
public class initKerbal : MonoBehaviour {
	public void Awake() {
		try {
			PartLoader.getPartInfoByName("kerbalEVA").partPrefab.AddModule("EVA_CMDS");
		} catch{}
	}
}

public class EVA_CMDS : PartModule {
	EVA_CMDS_b.EVAStuff me;

	[KSPEvent(guiActive = false, guiName = "Stay Put", active = false,  guiActiveUnfocused = true, unfocusedRange = 8)] public void stay() {
//Stop the kerbal from doing the "following animation", set the "A.I" timer which I'm not exactly certain how it is implemented :S

		part.animation.Play("idle", PlayMode.StopAll);
		me.switchTime = EVA_CMDS_b.rand.Next(30);
		me.switchTime += Planetarium.fetch.time;

		me.follow = false;
		Events["stay"]	.active = false;
		Events["follow"]	.active = true;

		//Prelim Formations
		Events["tighten"]	.active = false;
		Events["loosen"]	.active = false;
	}

	[KSPEvent(guiActive = true, guiName = "Follow Me", active = true,  guiActiveUnfocused = true, unfocusedRange = 8)] public void follow() {
		Vector3	move	 = FlightGlobals.fetch.activeVessel.rigidbody.position;
				move	-= me.eva.rigidbody.position;
		part.vessel.SetRotation(Quaternion.LookRotation(move, me.eva.fUp));

		me.follow = true;
		Events["stay"]	.active = true;
		Events["follow"]	.active = false;

		//Prelim Formations
		Events["tighten"]	.active = !EVA_CMDS_b.inUnion;
		Events["loosen"]	.active = EVA_CMDS_b.inUnion;
	}

//Prelim Formations
	[KSPEvent(guiActive = false, guiName = "Tighten Up", active = false,  guiActiveUnfocused = true, unfocusedRange = 8)] public void tighten() {
		EVA_CMDS_b.inUnion = true;
		foreach (EVA_CMDS_b.EVAStuff v in EVA_CMDS_b.fetch.EVAS) {
			if (v.follow) {
				v.module.Events["tighten"]	.active = false;
				v.module.Events["loosen"]	.active = true;
			}
		}
	}

	[KSPEvent(guiActive = false, guiName = "Loosen Up", active = false,  guiActiveUnfocused = true, unfocusedRange = 8)] public void loosen() {
		EVA_CMDS_b.inUnion = false;

		foreach (EVA_CMDS_b.EVAStuff v in EVA_CMDS_b.fetch.EVAS) {
			if (v.follow) {
				v.module.Events["tighten"]	.active = true;
				v.module.Events["loosen"]	.active = false;
			}
		}
	}
	public override void OnStart(StartState state) {
		Events["stay"]	.active = false;
		Events["follow"]	.active = true;
		Events["tighten"]	.active = false;
		Events["loosen"]	.active = false;

		foreach (EVA_CMDS_b.EVAStuff v in EVA_CMDS_b.fetch.EVAS) {
			if (v.part.vessel.id == part.vessel.id) {
				me = v;
				break;
			}
		}

// Initialize the Kerbal (EVAStuff)
		if (me == null) {
			me		= new EVA_CMDS_b.EVAStuff();
			me.part	= part;
			me.state	= 0;
			me.eva	= ((KerbalEVA) part.Modules["KerbalEVA"]);
			me.delta	= Vector3.zero;
			me.follow	= false;
			me.leader	= null;
			me.module	= this;
			me.switchTime  = EVA_CMDS_b.rand.Next(30);
			me.switchTime += Planetarium.fetch.time;
			EVA_CMDS_b.fetch.EVAS.Add(me);
		}
	}
}

[KSPAddon(KSPAddon.Startup.Flight, false)]
public class EVA_CMDS_b : MonoBehaviour {
	public List<EVAStuff> EVAS = new List<EVAStuff>();
	public static EVA_CMDS_b fetch;
	public static System.Random rand = new System.Random();
	public static bool inUnion = false;

	public void Awake() {
//This is suppose to function a bit like a singleton, hence 'fetch' needs to be an instance of the object
		fetch = this;
	}

	public void Update() {
		if (!FlightGlobals.ready || !FlightGlobals.fetch.activeVessel.isEVA) return;

		Guid		checkID	= FlightGlobals.fetch.activeVessel.id;
		double	geeForce	= FlightGlobals.currentMainBody.GeeASL;
		Vector3	leaderPos	= FlightGlobals.fetch.activeVessel.rigidbody.position;
		
		for (int x = EVAS.Count - 1; x >= 0; --x) {
			EVAStuff	v	= EVAS[x];
			KerbalEVA	me	= v.eva;
			Vector3	move	= -me.rigidbody.position;

			if (me == null || v.part == null) {
//The kerbal has become invalid, probably went out of range
//This removes it from the system and continues on with its life.
				EVAS.RemoveAt(x);
				continue;
			}
			if (v.part.vessel.id == checkID) {
//Reset the state if the player switches to the kerbal
//state is used so I can loop animations without checking if they're running
//Unity may have an equivalent interface, I just haven't come across it yet.
//(Other than checking isX animation running, that is fundemantally different)
				v.state = 0;
				continue;
			}
			if (me.isRagdoll) {
				//Much Kudos to Razchek for finally slaying the Ragdoll Monster!
				if (me.canRecover && me.fsm.TimeAtCurrentState > 1.21f) {
					foreach (KFSMEvent stateEvent in me.fsm.CurrentState.StateEvents) {
						if (stateEvent.name == "Recover Start") {
							me.fsm.RunEvent(stateEvent);
							v.state = 0;
							break;
						}
					}
				}
				continue;
			}

//If the player said "Follow Me"
			if (v.follow) {
				move += leaderPos;

//Current "debunching" code guesses where the kerbals are located by keeping everyone assigned to a leader;
//Leaders with too many followers have harder times getting more 'followers'
//Problem is that I only 'follow the leader' rather than 'follow to and wander around the leader'
//Second problem is that without targeting vessels, or excessive wandering, it is fairly difficult to keep them spread out.
				if (v.leader != null) {
					--v.leader.followers;
					v.leader = null;
				}
//If random switchtime occurs
			}else if (v.switchTime > Planetarium.fetch.time) {
//Debunching Code.
				if (v.leader != null) {
					--v.leader.followers;
					v.leader = null;
				}
				v.switchTime = EVA_CMDS_b.rand.Next(30);
				v.switchTime += Planetarium.fetch.time;
				continue;
//if no leader exists
			}else	if (v.leader == null) {
				double	perc = 1 / EVAS.Count;
				double	cnt = 0;
				Vector3	chk	= -me.rigidbody.position;

//prevention code for bunching
				if (v.followers < 2) 
//Finds a new 'leader' to follow
				foreach (EVAStuff s in EVAS) {
					cnt += perc;

//Cannot be following the player, cannot be the player, cannot be the same kerbal
					if (s.follow || s.part.vessel.id == checkID || v.part.vessel.id == s.part.vessel.id) continue;

//If it has a leader, check to see how many followers it has.
					if (s.leader != null) {
						EVAStuff nt = s.leader;
						byte followers = s.followers;

//mild recursion to see if the kerbal is following someone who is following
						while (nt.leader != null && followers < 2) {
							followers += nt.followers;
							nt = nt.leader;
						}

//Include your own followers (does not go recursively backwards)
						followers += v.followers;

//Never allow more than 2 followers on the "path" (1 kerbal (A) following 1 kerbal (B), B can get 1 more follower, A cannot). 
						if (followers >= 2 || followers == 1 && rand.NextDouble() >= 0.6) {
							continue;
						}
					}

//More debunching code... this weighs the "further than 5m" kerbals over the closer ones
					chk  = -me.rigidbody.position;
					chk += s.eva.rigidbody.position;
					if (rand.NextDouble() <= Math.Max(0.3,cnt) * (chk.sqrMagnitude / 25)) {
						v.leader = s;
					}else if (v.leader != null && rand.NextDouble() <= Math.Max(0.3,cnt)) {
						break;
					}
				}
				if (v.leader != null) {
					++v.leader.followers;
				}
				v.switchTime = EVA_CMDS_b.rand.Next(30);
				v.switchTime += Planetarium.fetch.time;
				continue;
//if leader now if following player
			}else if (v.leader.follow) {
				--v.leader.followers;
				v.leader = null;
				continue;
//Else follow the "random leader"
			}else move += v.leader.eva.rigidbody.position;

			float		sqrDist= move.sqrMagnitude;
			float		speed	 = TimeWarp.deltaTime;
			move.Normalize();

/** Animation Code **/
			if (v.part.WaterContact) {
				speed *= me.swimSpeed;
				if (v.state != 1) {
					me.animation.Play("swim_forward",	PlayMode.StopAll);
					v.state = 1;
				}
			}else if (!v.part.GroundContact) {
				speed = 0;
			}else if (sqrDist > 25 && geeForce >= me.minRunningGee) {
				speed *= me.runSpeed;
				if (v.state != 2) {
					me.animation.Play("wkC_run",		PlayMode.StopAll);
					v.state = 2;
				}
			}else if (geeForce >= me.minWalkingGee) {
				speed *= me.walkSpeed;
				if (v.state != 3) {
					me.animation.Play("wkC_forward",	PlayMode.StopAll);
					v.state = 3;
				}
			}else{
				speed *= me.boundSpeed;
				if (v.state != 4) {
					me.animation.Play("wkC_loG_forward",PlayMode.StopAll);
					v.state = 4;
				}
			}

//If you're going faster than you are far away, reduce the speed by such
			if (speed * speed > sqrDist) speed = sqrDist / speed;


//Maintains a specified distance away from other kerbals, this modifies the movement vector by v.delta in accordance to
// the distance both kerbals are away from each other.
			for (int y = x - 1; y >= 0; --y) {
				Vector3	delta	 = me.rigidbody.position;
						delta	-= EVAS[y].eva.rigidbody.position;

				if (delta.sqrMagnitude <= 1) {
					delta.Normalize();
					v.delta		+= delta;
					EVAS[y].delta	-= delta;
				}
			}

//This can be as low as '2' (and is technically suppose to be)
//At 2 it will somewhat hold formations, but has a tendency to push kerbals into ragdolls (i.e. overreacts)
//I need an exponential buffer to slow down the "translations".

//In long run, this should be kerbal specific and kerbal stats dictate how well they hold the formation
//Short run, fix smaller problems first.
//Notes that the kerbals are trying to maintain some kind of vectored cone
//putting in different restrictions to v.delta will push them into different 'formations'

			if (inUnion) {
				v.delta /= 2;
			}else	v.delta /= 3;


//Kerbals are "settling in" but not moving, should don't use the rotation animation because they take a while to 'settle in'
			if (sqrDist <= 4) {
				if (speed != 0 && v.delta != Vector3.zero) {
					v.delta *= speed;
					me.rigidbody.MovePosition(me.rigidbody.position + v.delta);
				}else if (v.state != 0) {
					v.state = 0;
					if (v.part.WaterContact) {
						me.animation.Play("swim_idle",	PlayMode.StopAll);
					}else	me.animation.Play("idle",		PlayMode.StopAll);
				}
			}else{
//Eventually want to get rotations right, v.delta is somewhat important, but it causes rapid head moving when very close.
				if (inUnion) v.part.vessel.SetRotation(Quaternion.LookRotation(move, me.fUp));

				move += v.delta;
				move *= speed;

				if (!inUnion) v.part.vessel.SetRotation(Quaternion.LookRotation(move, me.fUp));
				me.rigidbody.MovePosition(me.rigidbody.position + move);
			}
			v.delta = Vector3.zero;
		}
	}
	public class EVAStuff {
		public KerbalEVA	eva;
		public Part		part;
		public byte		state;
		public Vector3	delta;
		public EVA_CMDS	module;

		public EVAStuff	leader;
		public bool		follow;
		public byte		followers;
		public double	switchTime;
	}
}}


/* Notes */
//0.03 : 0.8 : 0.02 : 0.15 : 0.3 : 0.4 : 2 : 1.5
//print(me.boundForce + " : " + me.boundSpeed + " : " + me.boundThreshold + " : " + me.boundFrequency + " : " + me.boundSharpness + " : " + me.boundAttack + " : " + me.boundRelease + " : " + me.boundFallThreshold);
//
// Okay, I understand. A small force at frequency "boundFreq" is applied with the vector (BoundSharp (x , y) + BoundAttack(z)) to simulate "small bumps"; the kerbal is actually moved via boundSpeed
//

//To Do:
//me.fUp provides the tranform vector dictating the model's typical orientation
//move/rotVector provides the direction relative to the location of the kerbal

//Find out what vector the kerbal uses while idle (calculated, not grabbed) (note: it isn't normal to the terrain)
//rotVector should always be normal to the "idle" vector, if it isn't the leader is higher than the other kerbal which causes the strange "lean walking"
