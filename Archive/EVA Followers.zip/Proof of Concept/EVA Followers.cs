using UnityEngine;
using System.Collections.Generic;
using System;

namespace EVA_CMD {
[KSPAddon(KSPAddon.Startup.MainMenu, true)]
public class initKerbal : MonoBehaviour {
	public void Awake() {
		try {
			PartLoader.getPartInfoByName("kerbalEVA").partPrefab.AddModule("EVA_CMDS");
		} catch{}
	}
}

public class EVA_CMDS : PartModule {
	private EVA_CMDS_b.EVAStuff me;

	[KSPEvent(guiActive = false, guiName = "Stay Put", active = false,  guiActiveUnfocused = true, unfocusedRange = 8)] public void stay() {
		part.animation.Play("idle", PlayMode.StopAll);
		me.switchTime  = EVA_CMDS_b.rand.Next(30);
		me.switchTime += Planetarium.fetch.time;

		me.follow = false;
		Events["stay"]	.active = false;
		Events["follow"]	.active = true;
		Events["tighten"]	.active = false;
		Events["loosen"]	.active = false;
		Events["draw"]	.active = false;
	}

	[KSPEvent(guiActive = true, guiName = "Follow Me", active = true,  guiActiveUnfocused = true, unfocusedRange = 8)] public void follow() {
		Vector3	move	 = FlightGlobals.fetch.activeVessel.rigidbody.position;
				move	-= me.eva.rigidbody.position;
		part.vessel.SetRotation(Quaternion.LookRotation(move, me.eva.fUp));

		me.follow = true;
		Events["stay"]	.active = true;
		Events["follow"]	.active = false;
		Events["tighten"]	.active = !EVA_CMDS_b.inUnion;
		Events["loosen"]	.active = EVA_CMDS_b.inUnion;
		Events["draw"]	.active = EVA_CMDS_b.inUnion;
	}
	[KSPEvent(guiActive = false, guiName = "Tighten Up", active = false,  guiActiveUnfocused = true, unfocusedRange = 8)] public void tighten() {
		EVA_CMDS_b.inUnion = true;
		foreach (EVA_CMDS_b.EVAStuff v in EVA_CMDS_b.fetch.EVAS) {
			if (v.follow) {
				v.module.Events["tighten"]	.active = false;
				v.module.Events["loosen"]	.active = true;
				v.module.Events["draw"]		.active = true;
			}
		}
	}
	[KSPEvent(guiActive = false, guiName = "Loosen Up", active = false,  guiActiveUnfocused = true, unfocusedRange = 8)] public void loosen() {
		EVA_CMDS_b.inUnion = false;
		foreach (EVA_CMDS_b.EVAStuff v in EVA_CMDS_b.fetch.EVAS) {
			if (v.follow) {
				v.module.Events["tighten"]	.active = true;
				v.module.Events["loosen"]	.active = false;
				v.module.Events["draw"]		.active = false;
			}
		}
	}
	[KSPEvent(guiActive = false, guiName = "Draw Formation", active = false,  guiActiveUnfocused = true, unfocusedRange = 8)] public void draw() {

	}

	public override void OnStart(StartState state) {
		Events["stay"]	.active = false;
		Events["follow"]	.active = true;
		Events["tighten"]	.active = false;
		Events["loosen"]	.active = false;
		Events["draw"]	.active = false;

		foreach (EVA_CMDS_b.EVAStuff v in EVA_CMDS_b.fetch.EVAS) {
			if (v.part.vessel.id == part.vessel.id) {
				me = v;
				break;
			}
		}
		if (me == null) {
			me		= new EVA_CMDS_b.EVAStuff();
			me.part	= part;
			me.state	= 0;
			me.eva	= ((KerbalEVA) part.Modules["KerbalEVA"]);
			me.delta	= Vector3.zero;
			me.follow	= false;
			me.leader	= null;
			me.module	= this;
			me.switchTime  = EVA_CMDS_b.rand.Next(30);
			me.switchTime += Planetarium.fetch.time;
			EVA_CMDS_b.fetch.EVAS.Add(me);
		}
	}
}

[KSPAddon(KSPAddon.Startup.Flight, false)]
public class EVA_CMDS_b : MonoBehaviour {
	public		List<EVAStuff>	EVAS		= new List<EVAStuff>();
	public static	System.Random	rand		= new System.Random();
	public static	bool			inUnion	= false;
	public static	EVA_CMDS_b		fetch;

	public Vector3 vr1 = Vector3.zero;
	public Vector3 vr2 = Vector3.zero;

	public LineRenderer lr1 = null;
	public LineRenderer lr2 = null;

	public GameObject lineObj = null;
	public void Awake() {
		fetch = this;

		if (lr1 == null) {
			lineObj = new GameObject();
			lr1 = lineObj.AddComponent<LineRenderer>();
			lr1.useWorldSpace = true;
			lr1.material = new Material(Shader.Find("Particles/Additive"));
			lr1.SetWidth(0.05f, 0.05f);
			lr1.SetColors(Color.green, Color.green);

			lr1.SetVertexCount(4);
			for (int x = 0; x <= 4; ++x) {
				lr1.SetPosition(x, Vector3.zero);
			}
		}
		if (lr2 == null) {
			lineObj = new GameObject();
			lr2 = lineObj.AddComponent<LineRenderer>();
			lr2.useWorldSpace = true;
			lr2.material = new Material(Shader.Find("Particles/Additive"));
			lr2.SetWidth(0.05f, 0.05f);
			lr2.SetColors(Color.red, Color.red);

			lr2.SetVertexCount(60);
			for (int x = 0; x <= 60; ++x) {
				lr2.SetPosition(x, Vector3.zero);
			}
		}
	}

	public void Update() {
		if (!FlightGlobals.ready || !FlightGlobals.fetch.activeVessel.isEVA || FlightDriver.Pause) return;

		Guid		checkID	= FlightGlobals.fetch.activeVessel.id;
		double	geeForce	= FlightGlobals.currentMainBody.GeeASL;
		Vector3	leaderPos	= FlightGlobals.fetch.activeVessel.rigidbody.position;
		
		for (int x = EVAS.Count - 1; x >= 0; --x) {
			EVAStuff	v	= EVAS[x];
			KerbalEVA	me	= v.eva;
			Vector3	move	= -me.rigidbody.position;
			float		speed	= TimeWarp.deltaTime;
			float		sqrDist;

			if (me == null || v.part == null) {
				EVAS.RemoveAt(x);
				continue;
			}
			if (v.part.vessel.id == checkID) {
				vr1 *= 8;
				vr1 += 1.25f * me.referenceTransform.right;	
				vr1 /= 9;

				vr2 *= 8;
				vr2 += 1.25f * me.referenceTransform.up;		
				vr2 /= 9;

				lr2.SetPosition(5 * x, leaderPos);
				lr2.SetPosition(5 * x + 1, leaderPos);
				lr2.SetPosition(5 * x + 2, leaderPos);
				lr2.SetPosition(5 * x + 3, leaderPos);
				lr2.SetPosition(5 * x + 4, leaderPos);

				lr1.SetPosition(0, leaderPos + vr1 - vr2);
				lr1.SetPosition(1, leaderPos + vr1);
				lr1.SetPosition(2, leaderPos - vr1);
				lr1.SetPosition(3, leaderPos - vr1 - vr2);
				v.state = 0;
				continue;
			}
			if (me.isRagdoll) {
				if (me.canRecover && me.fsm.TimeAtCurrentState > 1.21f) {
					foreach (KFSMEvent stateEvent in me.fsm.CurrentState.StateEvents) {
						if (stateEvent.name == "Recover Start") {
							me.fsm.RunEvent(stateEvent);
							break;
						}
					}
				}
				v.state = 0;
				continue;
			}
			if (v.follow) {
				move += leaderPos;

				if (v.leader != null) {
					--v.leader.followers;
					v.leader = null;
				}

			}else if (v.switchTime > Planetarium.fetch.time) {
				if (v.leader != null) {
					--v.leader.followers;
					v.leader = null;
				}

				v.switchTime = EVA_CMDS_b.rand.Next(30);
				v.switchTime += Planetarium.fetch.time;
				continue;

			}else	if (v.leader == null) {
				double	perc	= 1 / EVAS.Count;
				double	cnt	= 0;
				if (v.followers < 2) 

				foreach (EVAStuff s in EVAS) {
					float		sqrDist2;
					Vector3	chk;
					cnt += perc;
					if (s.follow || s.part.vessel.id == checkID || v.part.vessel.id == s.part.vessel.id) continue;
					if (s.leader != null) {
						EVAStuff nt = s.leader;
						byte followers = s.followers;
						while (nt.leader != null && followers < 2) {
							followers += nt.followers;
							nt = nt.leader;
						}
						followers += v.followers;
						if (followers >= 2 || followers == 1 && rand.NextDouble() >= 0.6) {
							continue;
						}
					}

					chk		 = -me.rigidbody.position;
					chk		+= s.eva.rigidbody.position;
					sqrDist2	 = chk.sqrMagnitude;
					sqrDist2 /= 25;
					if (sqrDist2 > 1000) continue;
					if (rand.NextDouble() <= Math.Max(0.3, cnt) * sqrDist2) {
						v.leader = s;
					}else if (v.leader != null && rand.NextDouble() <= Math.Max(0.3, cnt)) {
						break;
					}
				}
				if (v.leader != null) {
					++v.leader.followers;
				}
				v.switchTime = EVA_CMDS_b.rand.Next(30);
				v.switchTime += Planetarium.fetch.time;
				continue;
			}else if (v.leader.follow) {
				--v.leader.followers;
				v.leader = null;
				continue;
			}else move += v.leader.eva.rigidbody.position;
			sqrDist = move.sqrMagnitude;

			if (v.part.WaterContact) {
				speed *= me.swimSpeed;
				if (v.state != 1) {
					me.animation.Play("swim_forward",	PlayMode.StopAll);
					v.state = 1;
				}
			}else if (!v.part.GroundContact) {
				speed = 0;
			}else if (sqrDist > 25 && geeForce >= me.minRunningGee) {
				speed *= me.runSpeed;
				if (v.state != 2) {
					me.animation.Play("wkC_run",		PlayMode.StopAll);
					v.state = 2;
				}
			}else if (geeForce >= me.minWalkingGee) {
				speed *= me.walkSpeed;
				if (v.state != 3) {
					me.animation.Play("wkC_forward",	PlayMode.StopAll);
					v.state = 3;
				}
			}else{
				speed *= me.boundSpeed;
				if (v.state != 4) {
					me.animation.Play("wkC_loG_forward",PlayMode.StopAll);
					v.state = 4;
				}
			}
			if (speed * speed > sqrDist) speed = sqrDist / speed;
			if (v.follow) {
				Vector3 delta = move;
				move		= Vector3.Project(move, vr2);
				sqrDist	= move.sqrMagnitude;
				delta	     -= move;

				if (delta.sqrMagnitude > vr2.sqrMagnitude) {
					move += delta;
				}

				lr2.SetPosition(5 * x, leaderPos);
				lr2.SetPosition(5 * x + 1, move + me.rigidbody.position);
				lr2.SetPosition(5 * x + 2, me.rigidbody.position);
				lr2.SetPosition(5 * x + 3, move + me.rigidbody.position);
				lr2.SetPosition(5 * x + 4, leaderPos);
			}

			for (int y = x - 1; y >= 0; --y) {
				Vector3	delta	 = me.rigidbody.position;
						delta	-= EVAS[y].eva.rigidbody.position;
				if (delta.sqrMagnitude <= 1) {
					v.delta		+= delta;
					if (inUnion) {
						EVAS[y].delta -= Vector3.Project(v.delta, delta);
					}else	EVAS[y].delta -= delta;
				}
			}

			v.delta.Normalize();
			if (inUnion) {
				v.delta /= 2;
			}else	v.delta /= 3;
			if (sqrDist <= 4) {
				if (speed != 0 && v.delta != Vector3.zero) {
					v.delta *= speed;
					me.rigidbody.MovePosition(me.rigidbody.position + v.delta);
				}else if (v.state != 0) {
					v.state = 0;
					if (v.part.WaterContact) {
						me.animation.Play("swim_idle",	PlayMode.StopAll);
					}else	me.animation.Play("idle",		PlayMode.StopAll);
				}
			}else{
				move.Normalize();
				if (inUnion) v.part.vessel.SetRotation(Quaternion.LookRotation(move, -me.referenceTransform.forward));

				move += v.delta;
				move *= speed;

				if (!inUnion) v.part.vessel.SetRotation(Quaternion.LookRotation(move, -me.referenceTransform.forward));
				me.rigidbody.MovePosition(me.rigidbody.position + move);
			}
			v.delta = Vector3.zero;
		}
	}
	public class EVAStuff {
		public KerbalEVA	eva;
		public Part		part;
		public byte		state;
		public Vector3	delta;
		public EVA_CMDS	module;

		public EVAStuff	leader;
		public bool		follow;
		public byte		followers;
		public double	switchTime;
	}
}}