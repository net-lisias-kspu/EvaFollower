using UnityEngine;
using System.Collections.Generic;
using System;

namespace EVA_CMD {
[KSPAddon(KSPAddon.Startup.MainMenu, true)]
public class initKerbal : MonoBehaviour {
	public void Awake() {
		try {
			PartLoader.getPartInfoByName("kerbalEVA").partPrefab.AddModule("EVA_CMDS");
		} catch{}
	}
}

public class EVA_CMDS : PartModule {
	private EVA_CMDS_b.EVAStuff me;

	[KSPEvent(guiActive = false, guiName = "Stay Put", active = false,  guiActiveUnfocused = true, unfocusedRange = 8)] public void stay() {
//Stop the kerbal from doing the "following animation", set the "A.I" timer which I'm not exactly certain how it is implemented :S

		part.animation.Play("idle", PlayMode.StopAll);
		me.switchTime  = EVA_CMDS_b.rand.Next(30);
		me.switchTime += Planetarium.fetch.time;

		me.follow = false;
		Events["stay"]	.active = false;
		Events["follow"]	.active = true;

		//Prelim Formations
		Events["tighten"]	.active = false;
		Events["loosen"]	.active = false;
		Events["draw"]	.active = false;
	}

	[KSPEvent(guiActive = true, guiName = "Follow Me", active = true,  guiActiveUnfocused = true, unfocusedRange = 8)] public void follow() {
		//Quick Rotation to Player
		Vector3	move	 = FlightGlobals.fetch.activeVessel.rigidbody.position;
				move	-= me.eva.rigidbody.position;
		part.vessel.SetRotation(Quaternion.LookRotation(move, me.eva.fUp));

		me.follow = true;
		Events["stay"]	.active = true;
		Events["follow"]	.active = false;

		//Prelim Formations
		Events["tighten"]	.active = !EVA_CMDS_b.inUnion;
		Events["loosen"]	.active = EVA_CMDS_b.inUnion;
		Events["draw"]	.active = EVA_CMDS_b.inUnion;
	}

//Prelim Formations
	[KSPEvent(guiActive = false, guiName = "Tighten Up", active = false,  guiActiveUnfocused = true, unfocusedRange = 8)] public void tighten() {
		EVA_CMDS_b.inUnion = true;
		foreach (EVA_CMDS_b.EVAStuff v in EVA_CMDS_b.fetch.EVAS) {
			if (v.follow) {
				v.module.Events["tighten"]	.active = false;
				v.module.Events["loosen"]	.active = true;
				v.module.Events["draw"]		.active = true;
			}
		}
	}
	[KSPEvent(guiActive = false, guiName = "Loosen Up", active = false,  guiActiveUnfocused = true, unfocusedRange = 8)] public void loosen() {
		EVA_CMDS_b.inUnion = false;
		foreach (EVA_CMDS_b.EVAStuff v in EVA_CMDS_b.fetch.EVAS) {
			if (v.follow) {
				v.module.Events["tighten"]	.active = true;
				v.module.Events["loosen"]	.active = false;
				v.module.Events["draw"]		.active = false;
			}
		}
	}
	[KSPEvent(guiActive = false, guiName = "Draw Formation", active = false,  guiActiveUnfocused = true, unfocusedRange = 8)] public void draw() {
		EVA_CMDS_b.Draw = true;
		EVA_CMDS_b.fetch.Formation.Clear();
		EVA_CMDS_b.fetch.lr1a.SetVertexCount(10);
		EVA_CMDS_b.fetch.lr1b.SetVertexCount(10);
		EVA_CMDS_b.fetch.lr1a.SetPosition(0, FlightGlobals.fetch.activeVessel.rigidbody.position);
		EVA_CMDS_b.fetch.lr1b.SetPosition(0, FlightGlobals.fetch.activeVessel.rigidbody.position);
		EVA_CMDS_b.fetch.fCnt = 0;
	}

	public override void OnStart(StartState state) {
		Events["stay"]	.active = false;
		Events["follow"]	.active = true;
		Events["tighten"]	.active = false;
		Events["loosen"]	.active = false;
		Events["draw"]	.active = true;

		foreach (EVA_CMDS_b.EVAStuff v in EVA_CMDS_b.fetch.EVAS) {
			if (v.part.vessel.id == part.vessel.id) {
				me = v;
				break;
			}
		}

// Initialize the Kerbal (EVAStuff)
		if (me == null) {
			me		= new EVA_CMDS_b.EVAStuff();
			me.part	= part;
			me.state	= 0;
			me.eva	= ((KerbalEVA) part.Modules["KerbalEVA"]);
			me.delta	= Vector3.zero;
			me.follow	= false;
			me.leader	= null;
			me.module	= this;
			me.switchTime  = EVA_CMDS_b.rand.Next(30);
			me.switchTime += Planetarium.fetch.time;
			EVA_CMDS_b.fetch.EVAS.Add(me);
		}
	}
}

[KSPAddon(KSPAddon.Startup.Flight, false)]
public class EVA_CMDS_b : MonoBehaviour {
	public		List<EVAStuff>	EVAS		= new List<EVAStuff>();
	public static	System.Random	rand		= new System.Random();
	public static	bool			inUnion	= false;
	public static	bool			Draw		= false;
	public static	EVA_CMDS_b		fetch;

	public int fCnt = 0;

	public Vector3 vr1 = Vector3.zero;
	public Vector3 vr2 = Vector3.zero;
	public List<Formations>	Formation	= new List<Formations>();

	public GameObject		lineObj;
	public LineRenderer	lr1a;
	public LineRenderer	lr1b;
	public LineRenderer	lr2;

//This is suppose to function a bit like a singleton, hence 'fetch' needs to be an instance of the object
	public void Awake() {
		fetch = this;

		if (lr1a == null) {
			lineObj = new GameObject();
			lr1a = lineObj.AddComponent<LineRenderer>();
			lr1a.useWorldSpace = true;
			lr1a.material = new Material(Shader.Find("Particles/Additive"));
			lr1a.SetWidth(0.05f, 0.05f);
			lr1a.SetColors(Color.green, Color.green);
		}
		if (lr1b == null) {
			lineObj = new GameObject();
			lr1b = lineObj.AddComponent<LineRenderer>();
			lr1b.useWorldSpace = true;
			lr1b.material = new Material(Shader.Find("Particles/Additive"));
			lr1b.SetWidth(0.05f, 0.05f);
			lr1b.SetColors(Color.green, Color.green);
		}
		if (lr2 == null) {
			lineObj = new GameObject();
			lr2 = lineObj.AddComponent<LineRenderer>();
			lr2.useWorldSpace = true;
			lr2.material = new Material(Shader.Find("Particles/Additive"));
			lr2.SetWidth(0.05f, 0.05f);
			lr2.SetColors(Color.red, Color.red);

			lr2.SetVertexCount(60);
			for (int x = 0; x <= 60; ++x) {
				lr2.SetPosition(x, Vector3.zero);
			}
		}
	}

	public void Update() {
		if (!FlightGlobals.ready || !FlightGlobals.fetch.activeVessel.isEVA || FlightDriver.Pause) return;

		Guid		checkID	= FlightGlobals.fetch.activeVessel.id;
		double	geeForce	= FlightGlobals.currentMainBody.GeeASL;
		Vector3	leaderPos	= FlightGlobals.fetch.activeVessel.rigidbody.position;
		
		for (int x = EVAS.Count - 1; x >= 0; --x) {
			EVAStuff	v	= EVAS[x];
			KerbalEVA	me	= v.eva;
			Vector3	move	= -me.rigidbody.position;
			float		speed	= TimeWarp.deltaTime;
			float		sqrDist;

			if (me == null || v.part == null) {
//The kerbal has become invalid, probably went out of range
//This removes it from the system and continues on with its life.
				EVAS.RemoveAt(x);
				continue;
			}
			if (v.part.vessel.id == checkID) {
//Reset the state if the player switches to the kerbal
//state is used so I can loop animations without checking if they're running
//Unity may have an equivalent interface, I just haven't come across it yet.
//(Other than checking isX animation running, that is fundemantally different)
				vr1 *= 8;
				vr1 += me.referenceTransform.right;	//right
				vr1 /= 9;

				vr2 *= 8;
				vr2 += me.referenceTransform.up;	//forward
				vr2 /= 9;

				if (!Draw) {
					lr1a.SetPosition(0, leaderPos);
					lr1b.SetPosition(0, leaderPos);

					fCnt = Formation.Count - 1;
					for (int s = 0; s <= fCnt; ++s) {
						lr1a.SetPosition(s + 1, leaderPos - Formation[s].x * vr2 + Formation[s].y * vr1);
						lr1b.SetPosition(s + 1, leaderPos - Formation[s].x * vr2 - Formation[s].y * vr1);
					}
					for (int s = fCnt; s < 10; ++s) {
						lr1a.SetPosition(s + 1, leaderPos - Formation[fCnt].x * vr2 + Formation[fCnt].y * vr1);
						lr1b.SetPosition(s + 1, leaderPos - Formation[fCnt].x * vr2 - Formation[fCnt].y * vr1);
					}
				}
				v.state = 0;
				continue;
			}
			if (me.isRagdoll) {
				//Much Kudos to Razchek for finally slaying the Ragdoll Monster!
				if (me.canRecover && me.fsm.TimeAtCurrentState > 1.21f) {
					foreach (KFSMEvent stateEvent in me.fsm.CurrentState.StateEvents) {
						if (stateEvent.name == "Recover Start") {
							me.fsm.RunEvent(stateEvent);
							break;
						}
					}
				}
				v.state = 0;
				continue;
			}

//If the player said "Follow Me"
			if (v.follow) {
				move += leaderPos;

//Current "debunching" code guesses where the kerbals are located by keeping everyone assigned to a leader;
//Leaders with too many followers have harder times getting more 'followers'
//Problem is that I only 'follow the leader' rather than 'follow to and wander around the leader'
//Second problem is that without targeting vessels, or excessive wandering, it is fairly difficult to keep them spread out.
				if (v.leader != null) {
					--v.leader.followers;
					v.leader = null;
				}
//If random switchtime occurs
			}else if (v.switchTime > Planetarium.fetch.time) {
//Debunching Code.
				if (v.leader != null) {
					--v.leader.followers;
					v.leader = null;
				}
//Set the Timer
				v.switchTime = EVA_CMDS_b.rand.Next(30);
				v.switchTime += Planetarium.fetch.time;
				continue;
//if no leader exists
			}else	if (v.leader == null) {
				double	perc	= 1 / EVAS.Count;
				double	cnt	= 0;

//prevention code for bunching
				if (v.followers < 2) 
//Finds a new 'leader' to follow
				foreach (EVAStuff s in EVAS) {
					float		sqrDist2;
					Vector3	chk;
					cnt += perc;

//Cannot be following the player, cannot be the player, cannot be the same kerbal
					if (s.follow || s.part.vessel.id == checkID || v.part.vessel.id == s.part.vessel.id) continue;

//If it has a leader, check to see how many followers it has.
					if (s.leader != null) {
						EVAStuff nt = s.leader;
						byte followers = s.followers;

//mild recursion to see if the kerbal is following someone who is following
						while (nt.leader != null && followers < 2) {
							followers += nt.followers;
							nt = nt.leader;
						}

//Include your own followers (does not go recursively backwards)
						followers += v.followers;

//Never allow more than 2 followers on the "path" (1 kerbal (A) following 1 kerbal (B), B can get 1 more follower, A cannot). 
						if (followers >= 2 || followers == 1 && rand.NextDouble() >= 0.6) {
							continue;
						}
					}

					chk		 = -me.rigidbody.position;
					chk		+= s.eva.rigidbody.position;
					sqrDist2	 = chk.sqrMagnitude;
					sqrDist2 /= 25;

//Prevention code, kerbals shouldn't be allowed to move further than 50m away from their "general area"
					if (sqrDist2 > 1000) continue;

//More debunching code... this weighs the "further than 5m" kerbals over the closer ones
					if (rand.NextDouble() <= Math.Max(0.3, cnt) * sqrDist2) {
						v.leader = s;

//Randomizer, will continue to look for leaders even if one is found to "enhance randomness"
					}else if (v.leader != null && rand.NextDouble() <= Math.Max(0.3, cnt)) {
						break;
					}
				}
				if (v.leader != null) {
					++v.leader.followers;
				}
				v.switchTime = EVA_CMDS_b.rand.Next(30);
				v.switchTime += Planetarium.fetch.time;
				continue;
//if leader is now following player
			}else if (v.leader.follow) {
				--v.leader.followers;
				v.leader = null;
				continue;
//Else follow the "random leader"
			}else move += v.leader.eva.rigidbody.position;
			sqrDist = move.sqrMagnitude;

/** Animation Code **/
			if (v.part.WaterContact) {
				speed *= me.swimSpeed;
				if (v.state != 1) {
					me.animation.Play("swim_forward",	PlayMode.StopAll);
					v.state = 1;
				}
			}else if (!v.part.GroundContact) {
				speed = 0;
			}else if (sqrDist > 25 && geeForce >= me.minRunningGee) {
				speed *= me.runSpeed;
				if (v.state != 2) {
					me.animation.Play("wkC_run",		PlayMode.StopAll);
					v.state = 2;
				}
			}else if (geeForce >= me.minWalkingGee) {
				speed *= me.walkSpeed;
				if (v.state != 3) {
					me.animation.Play("wkC_forward",	PlayMode.StopAll);
					v.state = 3;
				}
			}else{
				speed *= me.boundSpeed;
				if (v.state != 4) {
					me.animation.Play("wkC_loG_forward",PlayMode.StopAll);
					v.state = 4;
				}
			}

//If you're going faster than you are far away, reduce the speed by such
			if (speed * speed > sqrDist) speed = sqrDist / speed;

//Formation Test 2, the "OMG WHAT THE HELL":
			if (v.follow && !Draw) {
//				lr1a.SetPosition(0, leaderPos);
//				lr1b.SetPosition(0, leaderPos);

				fCnt = Formation.Count - 1;
				Vector3 qmove, tmove, zmove;
				qmove = Vector3.zero;
				tmove = Vector3.zero;
				zmove = leaderPos;
				for (int s = 0; s <= fCnt; ++s) {
//					lr1a.SetPosition(s + 1, leaderPos - Formation[s].x * vr2 + Formation[s].y * vr1);
//					lr1b.SetPosition(s + 1, leaderPos - Formation[s].x * vr2 - Formation[s].y * vr1);
					Vector3 danto = leaderPos - Formation[s].x * vr2 - Formation[s].y * vr1;
					Vector3 delta = move;
					qmove		= Vector3.Project(move, zmove - danto);
					sqrDist	= qmove.sqrMagnitude;
					delta	     -= qmove;
					zmove		= danto;
					if (delta.sqrMagnitude > danto.sqrMagnitude) {
						qmove += delta;
					}
					tmove = qmove;
				}
				move = tmove;

				lr2.SetPosition(5 * x, leaderPos);
				lr2.SetPosition(5 * x + 1, move + me.rigidbody.position);
				lr2.SetPosition(5 * x + 2, me.rigidbody.position);
				lr2.SetPosition(5 * x + 3, move + me.rigidbody.position);
				lr2.SetPosition(5 * x + 4, leaderPos);
			}

//Maintains a specified distance away from other kerbals, this modifies the movement vector by v.delta in accordance to
// the distance both kerbals are away from each other.
			for (int y = x - 1; y >= 0; --y) {
				Vector3	delta	 = me.rigidbody.position;
						delta	-= EVAS[y].eva.rigidbody.position;
				if (delta.sqrMagnitude <= 1) {
					v.delta		+= delta;
					if (inUnion) {
						EVAS[y].delta -= Vector3.Project(v.delta, delta);
					}else	EVAS[y].delta -= delta;
				}
			}

//This can be as low as '2' (and is technically suppose to be)
//At 2 it will somewhat hold formations, but has a tendency to push kerbals into ragdolls (i.e. overreacts)
//I need an exponential buffer to slow down the "translations".

//In long run, this should be kerbal specific and kerbal stats dictate how well they hold the formation
//Short run, fix smaller problems first.
//Notes that the kerbals are trying to maintain some kind of vectored cone
//putting in different restrictions to v.delta will push them into different 'formations'
			v.delta.Normalize();
			if (inUnion) {
				v.delta /= 2;
			}else	v.delta /= 3;

//Kerbals are "settling in" but not moving, don't use the rotation animation because they take a while to 'settle in'
			if (sqrDist <= 4) {
				if (speed != 0 && v.delta != Vector3.zero) {
					v.delta *= speed;
					me.rigidbody.MovePosition(me.rigidbody.position + v.delta);
				}else if (v.state != 0) {
					v.state = 0;
					if (v.part.WaterContact) {
						me.animation.Play("swim_idle",	PlayMode.StopAll);
					}else	me.animation.Play("idle",		PlayMode.StopAll);
				}
			}else{
//Eventually want to get rotations right, v.delta is somewhat important, but it causes rapid head moving when very close.
//May be a good idea to limit the rotation to be +/- 5 degrees off leader; still won't stop rapid head motion.
				move.Normalize();
				if (inUnion) v.part.vessel.SetRotation(Quaternion.LookRotation(move, -me.referenceTransform.forward));

				move += v.delta;
				move *= speed;

				if (!inUnion) v.part.vessel.SetRotation(Quaternion.LookRotation(move, -me.referenceTransform.forward));
				me.rigidbody.MovePosition(me.rigidbody.position + move);
			}
			v.delta = Vector3.zero;
		}

		if (Draw) {
			Vector3 tmp = Input.mousePosition;

			tmp.x /= Screen.height;
			tmp.y /= Screen.height;

			tmp.x -= ((float) Screen.width) / (2f * Screen.height);
			tmp.y -= 0.5f;

			tmp.x *= -8;
			tmp.y *= -8;

			{
				float hi = tmp.x;
				tmp.x = tmp.y;
				tmp.y = hi;
			}

			Vector3 tmpx = -Vector3.Project(tmp, vr1);
			Vector3 tmpy = Vector3.Project(tmp, vr2);

//			tmp.z = leaderPos.z;
			for (int x = 9; x > fCnt; --x) {
				lr1a.SetPosition(x, leaderPos + tmpy + tmpx);
				lr1b.SetPosition(x, leaderPos + tmpy - tmpx);
			}
			if (Input.GetMouseButtonDown(0)) {
				Formation.Add(new Formations(tmpy.magnitude, tmpx.magnitude));
				++fCnt;
			}else if (Input.GetMouseButtonDown(2)) {
				Draw = false;
			}
		}
	}
	public class EVAStuff {
//Pointers are very cheap, easier to just keep them here
//Rather than hunt the information down

		public KerbalEVA	eva;
		public Part		part;
		public byte		state;
		public Vector3	delta;
		public EVA_CMDS	module;

		public EVAStuff	leader;
		public bool		follow;
		public byte		followers;
		public double	switchTime;
	}
	public class Formations {
		public float x;
		public float y;

		public Formations(float x, float y) {
			this.x = x;
			this.y = y;
		}
	}
}}


/* Notes */
//0.03 : 0.8 : 0.02 : 0.15 : 0.3 : 0.4 : 2 : 1.5
//print(me.boundForce + " : " + me.boundSpeed + " : " + me.boundThreshold + " : " + me.boundFrequency + " : " + me.boundSharpness + " : " + me.boundAttack + " : " + me.boundRelease + " : " + me.boundFallThreshold);
//
// Okay, I understand. A small force at frequency "boundFreq" is applied with the vector (BoundSharp (x , y) + BoundAttack(z)) to simulate "small bumps"; the kerbal is actually moved via boundSpeed
//

//To Do:
//me.fUp provides the tranform vector dictating the model's typical orientation
//move/rotVector provides the direction relative to the location of the kerbal

//Find out what vector the kerbal uses while idle (calculated, not grabbed) (note: it isn't normal to the terrain)
//rotVector should always be normal to the "idle" vector, if it isn't the leader is higher than the other kerbal which causes the strange "lean walking"
